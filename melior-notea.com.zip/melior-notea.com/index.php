﻿<?php
	include ("check_user_index.php");
	include ("add_notes.php");
	include ("remove_notes.php");
	include ("edit_notes.php");
	$title = "Melior Notea"
?>
<html>
<head>
	<meta charset="utf-8">
	<title><?echo $title;?></title>
	<link href="style.css" rel="stylesheet">
</head>
<body>
	<?include ("header.html");?>
	<div class="inputCreateNode">
		<form action="index.php" method="post">
			<input name="title" class="inputTitle" type="text" placeholder="Заголовок" maxlength="22" id="inputCreateNodeTitle">
			<div class="inputCreateNodeNonDisplay" id="inputCreateNodeNonDisplay">
				<textarea name="text" class="inputText" maxlength="300" placeholder="Заметка"></textarea>
				<br>
				<input class="inputCreateNodeButton" type="submit">
				<input style="display : none;" name="email" type="text" value="<? echo $email ?>">
			</div>
		</form>
	</div>
	<div class="mainNote" id="main">
		<?
			include("display_notes.php");
		?>
	</div>
	<form id="formRemove" style="display: none" action="index.php" method="post">
		<input id="idRemove" name="idRemove" type="text">
		<input id="emailRemove" name="email" type="text">
		<input id="textEdit" name="textEdit" type="text">
		<input id="titleEdit" name="titleEdit" type="text">
		<input id="checkRemove" name="checkRemove" type="text">
		<input id="checkEdit" name="checkEdit" type="text">
		<input type="submit">
	</form>
	<script>
			var inputCreateNodeNonDisplay = document.getElementById('inputCreateNodeNonDisplay');
			var inputCreateNodeTitle = document.getElementById('inputCreateNodeTitle');
			var main = document.getElementById('main');
			inputCreateNodeTitle.onclick = function() {inputCreateNodeNonDisplay.style.display = 'block';};
			main.onclick = function() {inputCreateNodeNonDisplay.style.display = 'none';};
			
			function removeNote(object)
			{
				var formRemove = document.getElementById('formRemove');
				var idRemove = document.getElementById('idRemove');
				var emailRemove = document.getElementById('emailRemove');
				var checkRemove = document.getElementById('checkRemove');
				
				idRemove.value = object.id;
				emailRemove.value = '<? echo $email ?>';
				checkRemove.value = "yes";
				formRemove.submit();
			}
			function editNote(object)
			{
				var formEdit = document.getElementById('formRemove');
				var idEdit = document.getElementById('idRemove');
				var emailEdit = document.getElementById('emailRemove');
				var checkEdit = document.getElementById('checkEdit');
				var textEdit = document.getElementById('textEdit');
				var titleEdit = document.getElementById('titleEdit');
				
				idEdit.value = object.id;
				emailEdit.value = '<? echo $email ?>';
				textEdit.value = document.getElementById(object.id + 'text').value;
				titleEdit.value = document.getElementById(object.id + 'title').value;
				checkEdit.value = "yes";
				formEdit.submit();
			}
	</script>
</body>
</html>
