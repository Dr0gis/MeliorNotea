﻿<?php
	if (isset($_POST['title'])) 
	{ 
		$title = $_POST['title']; 
		if ($title == '') 
		{
			unset($title);
		}
	}
	if (isset($_POST['text'])) 
	{ 
		$text = $_POST['text']; 
		if ($text == '') 
		{
			unset($text);
		}
	}
	if ($email != '' and $title != '')
	{
		$collectionNotes->insert
		(
			array
			(
				'dateCreate' => date('d.m.Y H:i:s'),
				'title' => $title,
				'data' => $text,
				'user' => $email
			)
		);
	}
?>