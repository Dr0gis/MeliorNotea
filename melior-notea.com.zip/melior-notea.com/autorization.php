<?php
	include ("check_user.php");
	$title = "Авторизация";
?>
<html>
<head>
	<meta charset="utf-8">
	<title><?echo $title;?></title>
	<link href="style.css" rel="stylesheet">
	<script>
		function loadPage()
		{
			textEmail = "Пользователь с таким Email не найден, либо пароль не правильный.";
			autorization = <?echo $autorization;?>;
			if (autorization == false)
			{
				windowCenterErrorUserDisplay(textEmail);
			}
		}
		function windowCenterErrorUserDisplay(text)
		{
			document.getElementById('errorUser').style.display = 'block';
			document.getElementById('errorUserText').innerHTML = text;
		}
		function windowCenterErrorUserNonDisplay()
		{
			document.getElementById('errorUser').style.display = 'none';
		}
	</script>
</head>
<body onload="loadPage()">
	<?include ("header.html");?>
	<div class="errorUserAutorization" id="errorUser">
		<div class="errorUserHeader" align="center">
			Ошибка
		</div>
		<div class="errorUserText" align="center" id="errorUserText">
		</div>
		<div align="center" class="errorUserButton" onclick="windowCenterErrorUserNonDisplay()">
			<input type="button" value="ОК">
		</div>
	</div>
	<div class="main">
		<div class="autorization">
			<div class="registrationHeader" align="center">
				Авторизация
			</div>
			<div class="registrationMain">
				<form id="formSend" action="autorization.php" method="post">
					<div class="registrationInput">
						<p class="registrationText">
							E-mail
						</p>
						<input id="email" name="email" type="email" placeholder="E-mail" pattern="^[-\w.]+@([A-z0-9][-A-z0-9]+\.)+[A-z]{2,4}$" tabindex="1" autofocus required>
					</div>
					<div class="registrationInput">
						<p class="registrationText">
							Пароль
						</p>
						<input id="password" name="password" placeholder="Password" type="password" pattern="(?=^.{5,15}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" tabindex="3" maxlength="15" required>
					</div>
					<div class="registrationInput">
						<br>
						<input name="submitButton" type="submit" class="submit" tabindex="5">
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>
<?
	if ($autorization == "true")
	{
		$javascriptSend = "
		<script>
			emailSend = document.getElementById('email');
			passwordSend = document.getElementById('email');
			formSend = document.getElementById('formSend');
			emailSend.value = '" . $email . "';
			passwordSend = '" . $password . "';
			formSend.action = 'index.php';
			formSend.submit();
		</script>
		";
		echo $javascriptSend;
	}
?>