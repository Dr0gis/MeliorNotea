<?php
    $mongo = new MongoClient('localhost');
    $db = $mongo->test;
    $collectionNotes = $db->notes;
	$collectionUsers = $db->users;
?>