﻿<?php
	if (isset($_POST['checkEdit'])) 
	{ 
		$checkEdit = $_POST['checkEdit']; 
		if ($checkEdit == '') 
		{
			unset($checkEdit);
		}
	}
	if ($checkEdit == "yes")
	{
		if (isset($_POST['idRemove'])) 
		{ 
			$idEdit = $_POST['idRemove']; 
			if ($idEdit == '') 
			{
				unset($idEdit);
			}
		}
		if (isset($_POST['titleEdit'])) 
		{ 
			$titleEdit = $_POST['titleEdit']; 
			if ($titleEdit == '') 
			{
				unset($titleEdit);
			}
		}
		if (isset($_POST['textEdit'])) 
		{ 
			$textEdit = $_POST['textEdit']; 
			if ($textEdit == '') 
			{
				unset($textEdit);
			}
		}
		$collectionNotes->remove
		(
			array
			(
				'_id' => new MongoId ($idEdit)
			)
		);
		$collectionNotes->insert
		(
			array
			(
				'dateCreate' => date('d.m.Y H:i:s'),
				'title' => $titleEdit,
				'data' => $textEdit,
				'user' => $email
			)
		);
		
		/*$collectionNotes->remove
		(
			array
			(
				 '_id' => new MongoId ($idEdit),
			)
		);*/
	}
?>