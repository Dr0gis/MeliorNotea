﻿<?php
	if (isset($_POST['email'])) 
	{ 
		$email = $_POST['email']; 
		if ($email == '') 
		{
			unset($email);
		}
	} //заносим введенный пользователем логин в переменную $login, если он пустой, то уничтожаем переменную
    if (isset($_POST['password'])) 
	{ 
		$password = $_POST['password']; 
		if ($password == '') 
		{ 
			unset($password);
		} 
	}
	
	
	include ("database.php"); // подключение MongoDB
	
	$cursorCheck = $collectionUsers->find();
	$checkEmail = "false";
	$checkPassword = "false";
	foreach ($cursorCheck as $obj)
	{
		if ($obj["password"] == $password)
		{
			$checkPassword = "true";
		}
		if ($obj["email"] == $email)
		{
			$checkEmail = "true";
		}
		if ($checkPassword == "true" and $checkEmail == "true")
		{
			break;
		}
	}
	if ($email != '' or $password != '')
	{
		$autorization = "false";
	}
	if ($checkPassword == "true" and $checkEmail == "true")
	{
		$autorization = "true";
	}
?>