﻿<?php
	if (isset($_POST['email'])) 
	{ 
		$email = $_POST['email']; 
		if ($email == '') 
		{
			unset($email);
		}
	}
	include ("database.php"); // подключение MongoDB
?>