﻿<?php
    if (isset($_POST['email'])) 
	{ 
		$email = $_POST['email']; 
		if ($email == '') 
		{ 
			unset($email);
		} 
	} //заносим введенный пользователем логин в переменную $login, если он пустой, то уничтожаем переменную
	if (isset($_POST['nickname'])) 
	{ 
		$nickname = $_POST['nickname']; 
		if ($nickname == '') 
		{ 
			unset($nickname);
		}
	}
    if (isset($_POST['password'])) 
	{ 
		$password = $_POST['password']; 
		if ($password =='') 
		{ 
			unset($password);
		} 
	}
	if (isset($_POST['dateBorn'])) 
	{ 
		$dateBorn = $_POST['dateBorn'];
	}
	
    include ("database.php"); // подключение MongoDB
	// проверка на существование пользователя с таким же логином или мылом
    $cursorCheck = $collectionUsers->find();
	$checkNickname = "false";
	$checkEmail = "false";
	if ($nickname != '' and $checkEmail != '')
	{
		foreach ($cursorCheck as $obj) 
		{
			if ($obj[nickname] == $nickname)
			{
				$checkNickname = "true";
			}
		}
		foreach ($cursorCheck as $obj) 
		{
			if ($obj[email] == $email)
			{
				$checkEmail = "true";
			}
		}
	}
	// если такого нет, то сохраняем данные
	if ($checkNickname == "false" and $checkEmail == "false" and $email != '' and $nickname != '')
	{
		$collectionUsers->insert
		(
			array
			(
				'email' => $email,
				'nickname' => $nickname,
				'password' => $password,
				'dateBorn' => $dateBorn,
			)
		);
		$registration = true;
	}
?>