<?php
	include ("save_user.php");
	$title = "Регистрация";
	if ($registration == "true")
	{
		$javascriptSend = "
		<script>
			window.location.href='autorization.php'; 
		</script>
		";
		echo $javascriptSend;
	}
?>
<html>
<head>
	<meta charset="utf-8">
	<title><?echo $title;?></title>
	<link href="style.css" rel="stylesheet">
	<script>
		function loadPage()
		{
			textNickname = "Пользователь с таким Nickname уже существует.";
			textEmail = "Пользователь с таким Email уже существует.";
			checkNickname = <?echo $checkNickname;?>;
			checkEmail = <?echo $checkEmail;?>;
			if (checkNickname == true)
			{
				windowCenterErrorUserDisplay(textNickname);
			}
			if (checkEmail == true)
			{
				windowCenterErrorUserDisplay(textEmail);
			}
		}
		function windowCenterErrorUserDisplay(text)
		{
			document.getElementById('errorUser').style.display = 'block';
			document.getElementById('errorUserText').innerHTML = text;
		}
		function windowCenterErrorUserNonDisplay()
		{
			document.getElementById('errorUser').style.display = 'none';
		}
	</script>
</head>
<body onload="loadPage()">
	<?include ("header.html");?>
	<div class="errorUser" id="errorUser">
		<div class="errorUserHeader" align="center">
			Ошибка
		</div>
		<div class="errorUserText" align="center" id="errorUserText">
		</div>
		<div align="center" class="errorUserButton" onclick="windowCenterErrorUserNonDisplay()">
			<input type="button" value="ОК">
		</div>
	</div>
	<div class="main">
		<div class="registration">
			<div class="registrationHeader" align="center">
				Регистрация
			</div>
			<div class="registrationMain">
				<form action="registration.php" method="post">
					<div class="registrationInput">
						<p class="registrationText">
							E-mail*
						</p>
						<input name="email" type="email" placeholder="E-mail" pattern="^[-\w.]+@([A-z0-9][-A-z0-9]+\.)+[A-z]{2,4}$" tabindex="1" autofocus required>
					</div>
					<div class="registrationInput">
						<p class="registrationText">
							Никнейм*
						</p>
						<input name="nickname" placeholder="Nickname" type="text" pattern="^[a-zA-Z][a-zA-Z0-9-_\.]{3,15}$" tabindex="2" maxlength="15" required>
					</div>
					<div class="registrationInput">
						<p class="registrationText">
							Пароль*
						</p>
						<input name="password" placeholder="Password" type="password" pattern="(?=^.{5,15}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" tabindex="3" maxlength="15" required>
					</div>
					<div class="registrationInput">
						<p class="registrationText">
							Дата рождения
						</p>
						<input name="dateBorn" type="date" tabindex="4">
					</div>
					<div class="registrationInput">
						<p>
							
						</p>
						<input name="submit" type="submit" class="submit" tabindex="5">
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>