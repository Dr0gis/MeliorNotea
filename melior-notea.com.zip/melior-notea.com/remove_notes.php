﻿<?php
	if (isset($_POST['checkRemove'])) 
	{ 
		$checkRemove = $_POST['checkRemove']; 
		if ($checkRemove == '') 
		{
			unset($checkRemove);
		}
	}
	if ($checkRemove == "yes")
	{
		if (isset($_POST['idRemove'])) 
		{ 
			$idRemove = $_POST['idRemove']; 
			if ($idRemove == '') 
			{
				unset($idRemove);
			}
		}
		//echo '<script>alert("' . $idRemove . '")</script>';
		$collectionNotes->remove
		(
			array
			(
				 '_id' => new MongoId ($idRemove),
			)
		);
	}
?>