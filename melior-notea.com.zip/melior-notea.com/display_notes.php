﻿<?php
	$cursorNotesUser = $collectionNotes->find();
	foreach ($cursorNotesUser as $obj)
	{
		if ($obj["user"] == $email)
		{
			$arrayNotes[] = $obj;
		}
	}
	if ($arrayNotes != null)
	{
		foreach ($arrayNotes as $obj)
		{
			$divNote[] = 
			'
				<div class="note">
					<div class="noteTitle">
						<input id="' . $obj['_id'] . 'title' . '" style="border: 0px; background: #00BFFF; color: #fff; font-size: 30px; width: 250px; font-family: Gabriola; padding-top: 0px;" type="text" value="' . $obj['title'] . '" maxlength="22">
						</input>
						<div onclick="removeNote(this)" id="' . $obj['_id'] . '" style="float: right; padding-right: 15px; padding-left: 13px; padding-top: 10px; padding-bottom: 11px; margin-top: -4px; border-left: 1px solid #fff; border-radius: 0 18px 0 0;">
							<img src="x.png" width="35px">
						</div>
						<div onclick="editNote(this)" id="' . $obj['_id'] . '" title="" style="float: right; padding-right: 15px; padding-left: 13px; padding-top: 10px; padding-bottom: 11px; margin-top: -4px; border-left: 1px solid #fff; border-radius: 0 18px 0 0;">
							<img src="edit.png" width="35px">
						</div>
					</div>
					<div class="noteText">
						<textarea id="' . $obj['_id'] . 'text' . '" style="border: 0px solid #fff; font-size: 20px; height: 220px; width: 380px; font-family: Gabriola;">' . $obj['data'] . '</textarea>
					</div>
					<!--<div id="' . $obj['_id'] . 'button' . '" style="display: block;">
						
					</div>-->
				</div>
			';
		}
	}
	if ($divNote != null)
	{
		foreach ($divNote as $obj)
		{
			echo $obj;
		}
	}
?>